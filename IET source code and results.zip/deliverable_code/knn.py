"""
knn.py
Part (b): k-Nearest Neighbour regressor implemented entirely from first principles
(no scikit-learn). Two distance metrics: Euclidean and Mahalanobis.
k is selected via a manually computed validation curve (train/validation MSE vs k).
"""
import numpy as np
import pandas as pd

FEATURES = [
    "rainfall_mm", "avg_temp_c", "humidity_pct", "soil_n_kg_ha", "soil_p_kg_ha",
    "soil_k_kg_ha", "soil_ph", "growing_degree_days", "rainfall_anomaly_index",
    "heat_stress_index", "soil_fertility_index",
]
TARGET = "yield_kg_ha"


def standardise(X, mu=None, sigma=None):
    if mu is None:
        mu = X.mean(axis=0)
        sigma = X.std(axis=0)
        sigma[sigma == 0] = 1.0
    return (X - mu) / sigma, mu, sigma


def euclidean_distance(x, X):
    """Vectorised Euclidean distance from a single query point x to every row of X."""
    diff = X - x
    return np.sqrt(np.sum(diff ** 2, axis=1))


def mahalanobis_distance(x, X, VI):
    """Mahalanobis distance using precomputed inverse covariance matrix VI.
    d(x, y) = sqrt((x-y)^T * VI * (x-y))
    """
    diff = X - x
    left = diff @ VI
    return np.sqrt(np.sum(left * diff, axis=1))


class KNNRegressorFromScratch:
    def __init__(self, k=5, metric="euclidean"):
        self.k = k
        self.metric = metric
        self.X_train = None
        self.y_train = None
        self.VI = None  # inverse covariance for Mahalanobis

    def fit(self, X, y):
        self.X_train = np.asarray(X, dtype=float)
        self.y_train = np.asarray(y, dtype=float)
        if self.metric == "mahalanobis":
            cov = np.cov(self.X_train, rowvar=False)
            cov += np.eye(cov.shape[0]) * 1e-6  # regularise for invertibility
            self.VI = np.linalg.inv(cov)
        return self

    def _distances(self, x):
        if self.metric == "euclidean":
            return euclidean_distance(x, self.X_train)
        elif self.metric == "mahalanobis":
            return mahalanobis_distance(x, self.X_train, self.VI)
        raise ValueError("Unknown metric")

    def predict_one(self, x):
        d = self._distances(x)
        idx = np.argpartition(d, self.k)[: self.k]
        # inverse-distance weighting (avoid div by zero)
        w = 1.0 / (d[idx] + 1e-8)
        return float(np.sum(w * self.y_train[idx]) / np.sum(w))

    def predict(self, X):
        X = np.asarray(X, dtype=float)
        return np.array([self.predict_one(x) for x in X])


def mse(y_true, y_pred):
    return float(np.mean((y_true - y_pred) ** 2))


def train_val_test_split(df, val_frac=0.15, test_frac=0.15, seed=7):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(df))
    n_val = int(len(df) * val_frac)
    n_test = int(len(df) * test_frac)
    val_idx = idx[:n_val]
    test_idx = idx[n_val:n_val + n_test]
    train_idx = idx[n_val + n_test:]
    return df.iloc[train_idx].reset_index(drop=True), \
           df.iloc[val_idx].reset_index(drop=True), \
           df.iloc[test_idx].reset_index(drop=True)


def validation_curve(df, k_values, metric="euclidean", sample_train=2500, sample_val=600, seed=7):
    train_df, val_df, _ = train_val_test_split(df, seed=seed)
    train_df = train_df.sample(n=min(sample_train, len(train_df)), random_state=seed)
    val_df = val_df.sample(n=min(sample_val, len(val_df)), random_state=seed)

    Xtr_raw = train_df[FEATURES].values
    Xtr, mu, sigma = standardise(Xtr_raw)
    ytr = train_df[TARGET].values
    Xval, _, _ = standardise(val_df[FEATURES].values, mu, sigma)
    yval = val_df[TARGET].values

    results = []
    for k in k_values:
        model = KNNRegressorFromScratch(k=k, metric=metric).fit(Xtr, ytr)
        train_pred = model.predict(Xtr[:400])   # subsample for speed on train
        val_pred = model.predict(Xval)
        results.append({
            "k": k,
            "train_mse": mse(ytr[:400], train_pred),
            "val_mse": mse(yval, val_pred),
        })
    return pd.DataFrame(results)


if __name__ == "__main__":
    df = pd.read_csv("data/processed/agro_climatic_clean.csv")
    k_values = [1, 2, 3, 5, 8, 10, 15, 20, 30, 50]
    vc_euclid = validation_curve(df, k_values, metric="euclidean")
    print("Validation curve (Euclidean):")
    print(vc_euclid)
    best_k = int(vc_euclid.loc[vc_euclid["val_mse"].idxmin(), "k"])
    print("Best k (Euclidean):", best_k)
    vc_euclid.to_csv("results/validation_curve_euclidean.csv", index=False)
