import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

plt.rcParams.update({"font.size": 11, "figure.dpi": 150})

df = pd.read_csv("data/processed/agro_climatic_clean.csv")
vc_e = pd.read_csv("results/validation_curve_euclidean.csv")
vc_m = pd.read_csv("results/validation_curve_mahalanobis.csv")
vc_lwr = pd.read_csv("results/lwr_tau_validation_curve.csv")
scal = pd.read_csv("results/scalability_results.csv")

# 1. Rainfall vs Yield scatter with LOESS-like trend, coloured by season
fig, ax = plt.subplots(figsize=(6.5, 4.5))
colors = {"Kharif": "#2E7D32", "Rabi": "#1565C0", "Zaid": "#E65100"}
for season, c in colors.items():
    sub = df[df.season == season].sample(min(1200, (df.season == season).sum()), random_state=1)
    ax.scatter(sub.rainfall_mm, sub.yield_kg_ha, s=6, alpha=0.35, color=c, label=season)
ax.set_xlabel("Seasonal rainfall (mm)")
ax.set_ylabel("Crop yield (kg/ha)")
ax.set_title("Rainfall vs. Crop Yield by Season")
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig("plots/01_rainfall_vs_yield.png")
plt.close(fig)

# 2. Yield trend over years by district (mean), showing climate drift
fig, ax = plt.subplots(figsize=(6.5, 4.5))
yearly = df.groupby("year")["yield_kg_ha"].mean()
ax.plot(yearly.index, yearly.values, marker="o", color="#4527A0")
ax.set_xlabel("Year")
ax.set_ylabel("Mean yield (kg/ha)")
ax.set_title("Region-Wide Mean Yield Trend (2005-2023)")
fig.tight_layout()
fig.savefig("plots/02_yield_trend_over_years.png")
plt.close(fig)

# 3. Validation curves: k-NN Euclidean vs Mahalanobis
fig, ax = plt.subplots(figsize=(6.5, 4.5))
ax.plot(vc_e.k, vc_e.val_mse, marker="o", label="Euclidean - validation MSE")
ax.plot(vc_m.k, vc_m.val_mse, marker="s", label="Mahalanobis - validation MSE")
ax.set_xlabel("k (number of neighbours)")
ax.set_ylabel("Validation MSE")
ax.set_title("k-NN Validation Curve: Choosing k")
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig("plots/03_knn_validation_curve.png")
plt.close(fig)

# 4. LWR tau validation curve (bias-variance tradeoff)
fig, ax = plt.subplots(figsize=(6.5, 4.5))
ax.plot(vc_lwr.tau, vc_lwr.train_mse, marker="o", label="Train MSE")
ax.plot(vc_lwr.tau, vc_lwr.val_mse, marker="s", label="Validation MSE")
ax.set_xlabel("Bandwidth tau")
ax.set_ylabel("MSE")
ax.set_title("Locally Weighted Regression: Bias-Variance Tradeoff")
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig("plots/04_lwr_bias_variance.png")
plt.close(fig)

# 5. Scalability: brute-force vs KD-tree query time
fig, ax = plt.subplots(figsize=(6.5, 4.5))
ax.plot(scal.n_records, scal.brute_force_ms_per_query, marker="o", label="Brute-force k-NN (vectorised)")
ax.plot(scal.n_records, scal.kdtree_ms_per_query, marker="s", label="KD-tree k-NN (pure Python)")
ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlabel("Dataset size N (log scale)")
ax.set_ylabel("Query time per point, ms (log scale)")
ax.set_title("Scalability: Query Latency vs. Dataset Size")
ax.legend(frameon=False)
fig.tight_layout()
fig.savefig("plots/05_scalability_query_time.png")
plt.close(fig)

# 6. Soil fertility index vs yield, hexbin (density) - actionable insight
fig, ax = plt.subplots(figsize=(6.5, 4.5))
hb = ax.hexbin(df.soil_fertility_index, df.yield_kg_ha, gridsize=30, cmap="YlGnBu", mincnt=1)
ax.set_xlabel("Soil fertility index (0-1)")
ax.set_ylabel("Crop yield (kg/ha)")
ax.set_title("Soil Fertility vs. Yield (Density)")
fig.colorbar(hb, ax=ax, label="Record count")
fig.tight_layout()
fig.savefig("plots/06_soil_fertility_density.png")
plt.close(fig)

# 7. District-level risk: share of low-yield seasons (policy-relevant)
fig, ax = plt.subplots(figsize=(7.5, 5))
thresh = df.yield_kg_ha.quantile(0.25)
risk = df.assign(low_yield=df.yield_kg_ha <= thresh).groupby("district")["low_yield"].mean().sort_values(ascending=False)
ax.barh(risk.index[:10], risk.values[:10], color="#C62828")
ax.invert_yaxis()
ax.set_xlabel("Share of seasons in bottom yield quartile")
ax.set_title("Top 10 Highest-Risk Districts (Low-Yield Frequency)")
fig.tight_layout()
fig.savefig("plots/07_district_risk_ranking.png")
plt.close(fig)

print("All plots generated.")
