"""
lwr.py
Part (c): Locally Weighted Regression (LWR) implemented from first principles.
For each query point x0, fits a locally weighted least-squares line using a
Gaussian kernel, solving:
    theta(x0) = (X^T W X)^-1 X^T W y
where W = diag(w_i), w_i = exp(-||x_i - x0||^2 / (2*tau^2))
"""
import numpy as np
import pandas as pd
from knn import FEATURES, TARGET, standardise, mse, train_val_test_split


def gaussian_kernel_weights(X, x0, tau):
    diff = X - x0
    sq_dist = np.sum(diff ** 2, axis=1)
    return np.exp(-sq_dist / (2 * tau ** 2))


def lwr_predict_one(X_train, y_train, x0, tau, ridge=1e-6):
    n, d = X_train.shape
    Xb = np.hstack([np.ones((n, 1)), X_train])          # add bias column
    w = gaussian_kernel_weights(X_train, x0, tau)
    W = np.diag(w)
    XtW = Xb.T @ W
    A = XtW @ Xb + ridge * np.eye(d + 1)                  # ridge for numerical stability
    b = XtW @ y_train
    theta = np.linalg.solve(A, b)
    x0b = np.concatenate([[1.0], x0])
    return float(x0b @ theta)


def lwr_predict(X_train, y_train, X_query, tau):
    return np.array([lwr_predict_one(X_train, y_train, x0, tau) for x0 in X_query])


def tau_validation_curve(df, tau_values, sample_train=1500, sample_val=400, seed=7):
    train_df, val_df, _ = train_val_test_split(df, seed=seed)
    train_df = train_df.sample(n=min(sample_train, len(train_df)), random_state=seed)
    val_df = val_df.sample(n=min(sample_val, len(val_df)), random_state=seed)

    Xtr_raw = train_df[FEATURES].values
    Xtr, mu, sigma = standardise(Xtr_raw)
    ytr = train_df[TARGET].values
    Xval, _, _ = standardise(val_df[FEATURES].values, mu, sigma)
    yval = val_df[TARGET].values

    rows = []
    for tau in tau_values:
        val_pred = lwr_predict(Xtr, ytr, Xval, tau)
        train_pred = lwr_predict(Xtr, ytr, Xtr[:200], tau)
        rows.append({
            "tau": tau,
            "train_mse": mse(ytr[:200], train_pred),
            "val_mse": mse(yval, val_pred),
        })
    return pd.DataFrame(rows)


if __name__ == "__main__":
    df = pd.read_csv("data/processed/agro_climatic_clean.csv")
    tau_values = [0.3, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 5.0]
    vc = tau_validation_curve(df, tau_values)
    print(vc)
    vc.to_csv("results/lwr_tau_validation_curve.csv", index=False)
