"""
candidate_elimination.py
Part (d): Candidate-Elimination (version-space) algorithm applied to a discretised
version of the problem: classify each season-district instance into a HIGH-YIELD
("positive") vs NOT-HIGH-YIELD concept, using conjunctive hypotheses over
discretised (binned) attributes. '?' = any value accepted, a specific value =
that value required, and a contradictory attribute is marked with the null
symbol (represented here as None).
"""
import numpy as np
import pandas as pd

ATTRS = ["rainfall_bin", "temp_bin", "soil_fert_bin", "season"]


def discretise(df):
    df = df.copy()
    df["rainfall_bin"] = pd.qcut(df["rainfall_mm"], 3, labels=["Low", "Medium", "High"])
    df["temp_bin"] = pd.qcut(df["avg_temp_c"], 3, labels=["Cool", "Moderate", "Hot"])
    df["soil_fert_bin"] = pd.qcut(df["soil_fertility_index"], 3, labels=["Poor", "Average", "Rich"])
    yield_thresh = df["yield_kg_ha"].quantile(0.75)
    df["high_yield"] = df["yield_kg_ha"] >= yield_thresh
    return df


def more_general(h1, h2):
    """Return True if h1 is more-or-equally general than h2."""
    for a, b in zip(h1, h2):
        if a == "0":
            return False
        if a != "?" and a != b:
            return False
    return True


def consistent(h, instance):
    for hv, iv in zip(h, instance):
        if hv == "0":
            return False
        if hv != "?" and hv != iv:
            return False
    return True


def generalise_to_cover(h, instance):
    new_h = list(h)
    for i, (hv, iv) in enumerate(zip(h, instance)):
        if hv == "0":
            new_h[i] = iv
        elif hv != iv:
            new_h[i] = "?"
    return tuple(new_h)


def specialise_against(h, instance, attr_domains):
    specialisations = []
    for i, (hv, iv) in enumerate(zip(h, instance)):
        if hv == "?":
            for val in attr_domains[i]:
                if val != iv:
                    new_h = list(h)
                    new_h[i] = val
                    specialisations.append(tuple(new_h))
    return specialisations


def candidate_elimination(instances, labels, attr_domains):
    n_attrs = len(attr_domains)
    S = [tuple(["0"] * n_attrs)]
    G = [tuple(["?"] * n_attrs)]

    for instance, label in zip(instances, labels):
        instance = tuple(instance)
        if label:  # positive example
            G = [g for g in G if consistent(g, instance)]
            new_S = []
            for s in S:
                if consistent(s, instance):
                    new_S.append(s)
                else:
                    gen = generalise_to_cover(s, instance)
                    if any(more_general(g, gen) for g in G):
                        new_S.append(gen)
            # remove hypotheses in S more general than another hypothesis in S
            S = [s for s in new_S if not any(s != s2 and more_general(s2, s) for s2 in new_S)]
        else:  # negative example
            S = [s for s in S if not consistent(s, instance)]
            new_G = []
            for g in G:
                if not consistent(g, instance):
                    new_G.append(g)
                else:
                    specs = specialise_against(g, instance, attr_domains)
                    for sp in specs:
                        if any(more_general(sp, s) for s in S) or not S:
                            new_G.append(sp)
            G = [g for g in new_G if not any(g != g2 and more_general(g, g2) for g2 in new_G)]
    return S, G


if __name__ == "__main__":
    df = pd.read_csv("data/processed/agro_climatic_clean.csv")
    df = discretise(df)
    sample = df.sample(n=60, random_state=11).reset_index(drop=True)  # small consistent window

    attr_domains = [
        sorted(df["rainfall_bin"].astype(str).unique()),
        sorted(df["temp_bin"].astype(str).unique()),
        sorted(df["soil_fert_bin"].astype(str).unique()),
        sorted(df["season"].astype(str).unique()),
    ]

    instances = sample[ATTRS].astype(str).values.tolist()
    labels = sample["high_yield"].values.tolist()

    S, G = candidate_elimination(instances, labels, attr_domains)
    print("Attributes:", ATTRS)
    print("Specific boundary S:")
    for s in S:
        print(" ", s)
    print("General boundary G:")
    for g in G:
        print(" ", g)

    with open("results/candidate_elimination_output.txt", "w") as f:
        f.write("Attributes: " + str(ATTRS) + "\n\n")
        f.write("Specific boundary (S):\n")
        for s in S:
            f.write("  " + str(s) + "\n")
        f.write("\nGeneral boundary (G):\n")
        for g in G:
            f.write("  " + str(g) + "\n")
