"""
scalability.py
Part (e): Measure time/memory complexity of the from-scratch k-NN and LWR
implementations as N scales from 10^3 to 10^6, then prototype a KD-tree index
(built from first principles) to demonstrate a sub-linear-query alternative to
brute-force k-NN search.
"""
import time
import tracemalloc
import numpy as np
import pandas as pd
from knn import KNNRegressorFromScratch, standardise

D = 8  # feature dimensionality for synthetic scaling experiment


def make_synthetic(n, d=D, seed=0):
    rng = np.random.default_rng(seed)
    X = rng.normal(0, 1, size=(n, d))
    y = X.sum(axis=1) + rng.normal(0, 0.5, size=n)
    return X, y


def measure_brute_force(n, n_queries=25, k=15):
    X, y = make_synthetic(n)
    Xs, _, _ = standardise(X)
    model = KNNRegressorFromScratch(k=k, metric="euclidean").fit(Xs, y)
    queries = Xs[:n_queries]

    tracemalloc.start()
    t0 = time.perf_counter()
    _ = model.predict(queries)
    t1 = time.perf_counter()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    per_query_ms = (t1 - t0) / n_queries * 1000
    return per_query_ms, peak / (1024 ** 2)  # ms per query, MB


# ---------------- KD-Tree from scratch ----------------
class KDNode:
    __slots__ = ("point", "label", "axis", "left", "right")

    def __init__(self, point, label, axis, left=None, right=None):
        self.point = point
        self.label = label
        self.axis = axis
        self.left = left
        self.right = right


def build_kdtree(points, labels, depth=0):
    if len(points) == 0:
        return None
    axis = depth % points.shape[1]
    order = np.argsort(points[:, axis])
    points, labels = points[order], labels[order]
    mid = len(points) // 2
    return KDNode(
        point=points[mid], label=labels[mid], axis=axis,
        left=build_kdtree(points[:mid], labels[:mid], depth + 1),
        right=build_kdtree(points[mid + 1:], labels[mid + 1:], depth + 1),
    )


def kdtree_knn(node, query, k, heap):
    """heap: list of (neg_dist, label) kept sorted, size <= k (simple list-based
    'heap' for clarity; a real production system would use heapq)."""
    if node is None:
        return
    dist = np.linalg.norm(node.point - query)
    heap.append((dist, node.label))
    heap.sort(key=lambda t: t[0])
    if len(heap) > k:
        heap.pop()

    axis = node.axis
    diff = query[axis] - node.point[axis]
    near, far = (node.left, node.right) if diff < 0 else (node.right, node.left)
    kdtree_knn(near, query, k, heap)
    # Only explore the far branch if it could contain a closer point than the
    # current k-th best distance (the key pruning step that gives KD-trees
    # their average sub-linear query time).
    if len(heap) < k or abs(diff) < heap[-1][0]:
        kdtree_knn(far, query, k, heap)


def measure_kdtree(n, n_queries=25, k=15):
    X, y = make_synthetic(n)
    Xs, _, _ = standardise(X)

    t0 = time.perf_counter()
    tree = build_kdtree(Xs.copy(), y.copy())
    build_time = time.perf_counter() - t0

    queries = Xs[:n_queries]
    t0 = time.perf_counter()
    for q in queries:
        heap = []
        kdtree_knn(tree, q, k, heap)
    t1 = time.perf_counter()
    per_query_ms = (t1 - t0) / n_queries * 1000
    return build_time * 1000, per_query_ms


if __name__ == "__main__":
    import sys
    sizes = [1_000, 5_000, 10_000, 50_000, 100_000, 300_000]
    rows = []
    for n in sizes:
        bf_ms, bf_mb = measure_brute_force(n)
        kd_build_ms, kd_query_ms = measure_kdtree(n)
        rows.append({
            "n_records": n,
            "brute_force_ms_per_query": bf_ms,
            "brute_force_peak_mb": bf_mb,
            "kdtree_build_ms": kd_build_ms,
            "kdtree_ms_per_query": kd_query_ms,
        })
        print(rows[-1])
    pd.DataFrame(rows).to_csv("results/scalability_results.csv", index=False)
